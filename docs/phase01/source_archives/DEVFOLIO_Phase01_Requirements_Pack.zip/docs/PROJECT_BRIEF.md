# DEVFOLIO OS — Project Brief (Draft v1.0)

**Status:** Draft for owner approval. **Owner:** Portfolio administrator. **Date:** 2026-10-22.

## Vision
Build a publicly accessible, responsive and discoverable professional portfolio for a software developer and AI/ML researcher, paired with a private form-driven CMS that allows routine content updates without source-code edits or redeployment.

## Target audiences
1. Recruiters and hiring managers evaluating engineering capability.
2. Engineers and potential collaborators evaluating projects, code and technical decisions.
3. Researchers evaluating methods, experiments, publications and reproducibility.
4. General visitors seeking biography, resume, contact information or writing.
5. The owner acting as sole administrator.

## Project objectives
- Communicate professional identity clearly within the first screen.
- Provide navigable, detailed evidence of engineering and research work.
- Ensure every content type needed at launch can be maintained through the admin dashboard.
- Maintain trustworthy claims: work-in-progress research must not be presented as published research.
- Deploy securely under HTTPS with appropriate backup, recovery and monitoring controls.
- Keep the architecture maintainable and economic for a one-person portfolio.

## Constraints and architectural intent
- JavaScript, React, Node.js, Express, PostgreSQL.
- React server-rendering strategy, modular monolith, admin and public pages under a shared origin where practicable.
- PostgreSQL is the source of truth; large files live in object storage.
- Authentication: sole admin account, password + verified email login challenge, no visitor registration.
- Managed hosting, version-controlled schema and tested migration path.
- Prefer vetted, compatible open-source packages to reinventing generic components.

## In-scope release 1
Public pages, content CRUD, media uploads, draft/preview/publish, SEO, resume, contact form, admin authentication, backup and deployment.

## Out-of-scope release 1
Visitor accounts, online payments, chatbots, custom ML inference, microservices, multiple editors, automatic GitHub synchronization, multilingual translation, scheduled publication.

## Success criteria
All P0 functional and non-functional requirements pass their acceptance tests; public site is responsive and usable; dynamic content updates without redeployment; private data remains private; backups can be restored.

## Critical assumptions to approve
Real content will be provided by the owner; public-facing achievements require evidence; third-party provider choices remain provisional until implementation; legal/privacy obligations depend on final analytics and contact setup.
