# DEVFOLIO OS — Phase 01 Requirements Pack

Prepared as an **editable first-draft specification**, not as an approved final SRS. It contains no actual owner biography or invented achievements.

## How to use
1. Unzip this pack outside your project and review it.
2. Copy the files inside `docs/` to your existing repository `docs/` directory. Review before overwriting any existing documents.
3. In VS Code, review in this order: PROJECT_BRIEF, PAGE_INVENTORY, CONTENT_FIELDS, REQUIREMENTS_CATALOG, USER_STORIES, SRS, ACCEPTANCE_TESTS, OPEN_DECISIONS.
4. Complete `PHASE01_CHECKLIST.md`, update your existing `docs/PROJECT_STATUS.md`, and change SRS status to Approved only after review.
5. Save and push the documents through Git once validated.

### No npm dependencies should be installed just for requirements writing.
Project templates, UI packages, validation, ORM and test dependencies will be installed during architecture/scaffolding phases after versions are confirmed.

## Warnings
- The field dictionary is requirements-level; it is **not** a finalized SQL schema.
- Some P0 coverage in the provided test matrix is grouped; expand to full one-to-one traceability as part of sign-off.
- Validate file naming against your repo before copying. No GitHub changes were made by generating this pack.
