# Phase 01 — Owner Approval & GitHub Reconciliation Gate

**Status:** OPEN. Phase 01 historical materials recovered; **approved master SRS not verified**.

## Where files belong in the repository
Safest non-misleading location: `docs/phase01/draft/` with original source document names. Do **not** push the older SRS to `docs/SRS.md` or label it final approved until owner approves it or an authentic approved copy is located.

## Proposed decision protocol
1. If you have the real signed-off version on Windows, compare it with `01_CURRENT_HISTORICAL_DRAFT/docs/SRS.md`. Verify exact version, date, sign-off and any changed fields.
2. If not, review original SRS, 52 FR/24 NFR, project brief, field dictionary, 43 base acceptance checks, newly mapped gap tests and Phase 02 change impact.
3. Record explicit owner approval for each critical scope/security/privacy/content decision; resolve or deliberately defer risks.
4. Issue `docs/phase01/APPROVED_SRS.md` or an explicitly named master `docs/SRS.md` **only after** the owner approves the actual content/version, and reference its commit SHA.
5. Update `docs/phase01/SRS_RECONCILIATION.md` with verification evidence and re-run Phase 02 field/route traceability.
6. Do not mark untested acceptance checks as passing.

## Windows source-recovery checklist
Look for actual SRS in local Documents and your development checkout. Compare versions using Git or file diff; do not overwrite local work. Never upload credentials, private email contents, passwords or recovery codes to the repo.
